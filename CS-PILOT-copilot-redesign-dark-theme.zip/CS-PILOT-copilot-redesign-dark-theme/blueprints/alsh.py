"""
Blueprint alsh_bp - Module Analyse ALSH.

Fonctionnalites :
- Configuration des tranches d'age et des periodes
- Mapping des codes analytiques (max 3 par cellule periode × tranche d'age)
- Saisie des donnees NOE (heures de presence, nombre d'enfants differents)
- Tableau de bord : croisement donnees comptables bilan_fec / donnees NOE
- Calcul : heures, enfants, charges, produits, resultat, cout/heure,
           cout/enfant, reste a charge/enfant, taux de couverture
- Filtrage par date : si des periodes_vacances sont configurees pour l'annee,
  les donnees FEC sont restreintes aux mois couverts par chaque periode
  (evite le double-comptage quand le meme code analytique est utilise pour
  plusieurs periodes de vacances)
- Comparaison N/N-1/N-2 si les donnees sont disponibles
- Accessible aux profils directeur et comptable
"""
import json
from datetime import datetime, date as _date
from flask import (Blueprint, render_template, request, session,
                   flash, redirect, url_for, jsonify)
from database import get_db
from utils import login_required, get_setting, save_setting

alsh_bp = Blueprint('alsh_bp', __name__)


def _peut_acceder():
    return session.get('profil') in ('directeur', 'comptable')


# ── Correspondance periodes vacances (par mots-cles) ─────────────────────────

import unicodedata

_VACATION_KEYWORDS = {
    'hiver':     ['hiver'],
    'printemps': ['printemps', 'paques'],
    'ete':       ['ete', 'estival'],
    'toussaint': ['toussaint', 'automne'],
    'noel':      ['noel'],
}
_FAMILY_PAYMENTS_ACCOUNT_PREFIX = '7064'
_TARIF_REPARTITION_SETTING_KEY = 'alsh_tarif_repartition_quotients'
_DEFAULT_TARIF_REPARTITION = [
    {'id': 'qf_0_249', 'pct': 22.0},
    {'id': 'qf_250_499', 'pct': 20.0},
    {'id': 'qf_500_749', 'pct': 16.0},
    {'id': 'qf_750_999', 'pct': 14.0},
    {'id': 'qf_1000_1249', 'pct': 10.0},
    {'id': 'qf_1250_1499', 'pct': 8.0},
    {'id': 'qf_1500_1749', 'pct': 6.0},
    {'id': 'qf_1750_plus', 'pct': 4.0},
]


def _get_taux_logistique_global(conn, annee):
    """Retourne le taux logistique global de l'année, ou None s'il est absent."""
    row = conn.execute(
        'SELECT taux_global FROM bilan_taux_logistique WHERE annee = ?',
        (annee,)
    ).fetchone()
    if not row:
        return None
    try:
        return float(row['taux_global'])
    except (TypeError, ValueError):
        return None


def _normaliser(s):
    """Normalise une chaîne (minuscules, sans accents) pour la comparaison."""
    return unicodedata.normalize('NFD', s).encode('ascii', 'ignore').decode().lower()


def _get_tarif_repartition_quotients():
    """Retourne la répartition globale des quotients (valeurs par défaut sinon)."""
    raw = get_setting(_TARIF_REPARTITION_SETTING_KEY)
    if not raw:
        return [dict(x) for x in _DEFAULT_TARIF_REPARTITION]
    try:
        parsed = json.loads(raw)
    except (TypeError, ValueError):
        return [dict(x) for x in _DEFAULT_TARIF_REPARTITION]

    if not isinstance(parsed, list):
        return [dict(x) for x in _DEFAULT_TARIF_REPARTITION]

    parsed_map = {}
    for item in parsed:
        if not isinstance(item, dict):
            continue
        tranche_id = item.get('id')
        pct = item.get('pct')
        if not isinstance(tranche_id, str):
            continue
        try:
            pct_val = float(pct)
        except (TypeError, ValueError):
            continue
        if pct_val < 0:
            continue
        parsed_map[tranche_id] = pct_val

    result = []
    for item in _DEFAULT_TARIF_REPARTITION:
        result.append({
            'id': item['id'],
            'pct': parsed_map.get(item['id'], item['pct'])
        })
    return result


def _detecter_type_vacances(nom):
    """Retourne le type de vacances ('hiver', 'printemps', ...) depuis un nom, ou None."""
    nom_norm = _normaliser(nom)
    for type_vac, kws in _VACATION_KEYWORDS.items():
        if any(kw in nom_norm for kw in kws):
            return type_vac
    return None


def _mois_couverts_annee(date_debut_str, date_fin_str, annee):
    """Retourne le set des mois (1-12) couverts par une plage de dates dans l'annee donnee."""
    try:
        debut = _date.fromisoformat(date_debut_str)
        fin = _date.fromisoformat(date_fin_str)
    except (ValueError, TypeError, AttributeError):
        return set()
    if debut > fin:
        return set()
    mois = set()
    y, m = debut.year, debut.month
    end_y, end_m = fin.year, fin.month
    while (y, m) <= (end_y, end_m):
        if y == annee:
            mois.add(m)
        if m == 12:
            y, m = y + 1, 1
        else:
            m += 1
    return mois


def _build_periode_info(conn, periodes, annee):
    """
    Construit un dict {periode_id: (set_of_months_or_None, label_or_None, nb_jours_or_None)}.

    Pour chaque alsh_periode de type 'vacances' dont le nom correspond a une
    periodes_vacances de la BD (via mots-cles), retourne :
      - les mois couverts (pour le filtre des charges)
      - le label de dates affiche dans l'UI
      - le nombre de jours (pour le calcul pro-rata des produits)

    Pour les autres periodes (Mercredis, custom, ou vacances sans correspondance),
    retourne (None, None, None) = pas de filtre de date, pas de pro-rata.
    """
    # Chercher les periodes_vacances proches de l'annee (annee-1 a annee+1 pour
    # les vacances de Noel qui chevauchent deux annees civiles)
    years = (str(annee - 1), str(annee), str(annee + 1))
    ph = ','.join('?' * len(years))
    rows = conn.execute(
        "SELECT nom, date_debut, date_fin FROM periodes_vacances "
        f"WHERE strftime('%Y', date_debut) IN ({ph}) "
        f"  OR strftime('%Y', date_fin)   IN ({ph})",
        years * 2
    ).fetchall()

    # Regrouper par type, en ne gardant que les mois dans l'annee cible
    vacances_par_type = {}  # {type_vac: {mois, date_debut, date_fin}}
    for row in rows:
        tv = _detecter_type_vacances(row['nom'])
        if not tv:
            continue
        mois = _mois_couverts_annee(row['date_debut'], row['date_fin'], annee)
        if not mois:
            continue
        if tv not in vacances_par_type:
            vacances_par_type[tv] = {
                'mois': set(),
                'date_debut': row['date_debut'],
                'date_fin': row['date_fin'],
            }
        vacances_par_type[tv]['mois'] |= mois

    result = {}
    for p in periodes:
        if p['type'] == 'vacances':
            tv = _detecter_type_vacances(p['nom'])
            if tv and tv in vacances_par_type:
                vd = vacances_par_type[tv]
                try:
                    d_debut = _date.fromisoformat(vd['date_debut'])
                    d_fin = _date.fromisoformat(vd['date_fin'])
                    label = (
                        f"{d_debut.day:02d}/{d_debut.month:02d}"
                        f" – {d_fin.day:02d}/{d_fin.month:02d}/{d_fin.year}"
                    )
                    nb_jours = (d_fin - d_debut).days + 1 if d_fin >= d_debut else None
                except Exception:
                    label = None
                    nb_jours = None
                result[p['id']] = (vd['mois'], label, nb_jours)
            else:
                result[p['id']] = (None, None, None)
        else:
            result[p['id']] = (None, None, None)
    return result


# ── Page principale ──────────────────────────────────────────────────────────

@alsh_bp.route('/analyse-alsh')
@login_required
def analyse_alsh():
    """Affiche le module Analyse ALSH."""
    if not _peut_acceder():
        flash('Accès non autorisé.', 'error')
        return redirect(url_for('dashboard_bp.dashboard'))

    now = datetime.now()
    annee_courante = now.year
    annees = list(range(annee_courante - 3, annee_courante + 2))

    conn = get_db()
    try:
        annees_noe = conn.execute(
            'SELECT DISTINCT annee FROM alsh_saisie_noe ORDER BY annee DESC'
        ).fetchall()
        annees_fec = conn.execute(
            'SELECT DISTINCT annee FROM bilan_fec_imports ORDER BY annee DESC'
        ).fetchall()
        return render_template(
            'alsh.html',
            annees=annees,
            annee_courante=annee_courante,
            annees_noe=[r['annee'] for r in annees_noe],
            annees_fec=[r['annee'] for r in annees_fec],
        )
    finally:
        conn.close()


# ── Configuration : lecture ───────────────────────────────────────────────────

@alsh_bp.route('/api/alsh/config')
@login_required
def api_alsh_config():
    """Retourne la config globale : tranches d'age et periodes."""
    if not _peut_acceder():
        return jsonify({'error': 'Accès non autorisé'}), 403

    conn = get_db()
    try:
        tranches = conn.execute(
            'SELECT id, libelle, ordre, active FROM alsh_tranches_age ORDER BY ordre, id'
        ).fetchall()
        periodes = conn.execute(
            'SELECT id, nom, type, ordre, active FROM alsh_periodes ORDER BY ordre, id'
        ).fetchall()
        return jsonify({
            'tranches': [dict(r) for r in tranches],
            'periodes': [dict(r) for r in periodes],
            'tarif_repartition_quotients': _get_tarif_repartition_quotients(),
        })
    finally:
        conn.close()


@alsh_bp.route('/api/alsh/tarif-repartition', methods=['POST'])
@login_required
def api_alsh_save_tarif_repartition():
    """Sauvegarde la répartition globale des quotients pour le tarif optimal ALSH."""
    if not _peut_acceder():
        return jsonify({'error': 'Accès non autorisé'}), 403

    data = request.json or {}
    values = data.get('tarif_repartition_quotients')
    if not isinstance(values, list):
        return jsonify({'error': 'Format invalide.'}), 400

    allowed_ids = {item['id'] for item in _DEFAULT_TARIF_REPARTITION}
    parsed_map = {}
    for item in values:
        if not isinstance(item, dict):
            return jsonify({'error': 'Format invalide.'}), 400
        tranche_id = item.get('id')
        if tranche_id not in allowed_ids:
            return jsonify({'error': 'Tranche de quotient inconnue.'}), 400
        try:
            pct_val = float(item.get('pct'))
        except (TypeError, ValueError):
            return jsonify({'error': 'Pourcentage invalide.'}), 400
        if pct_val < 0:
            return jsonify({'error': 'Pourcentage invalide.'}), 400
        parsed_map[tranche_id] = pct_val

    normalized_values = []
    for item in _DEFAULT_TARIF_REPARTITION:
        normalized_values.append({
            'id': item['id'],
            'pct': parsed_map.get(item['id'], item['pct'])
        })

    save_setting(_TARIF_REPARTITION_SETTING_KEY, json.dumps(normalized_values))
    return jsonify({'success': True, 'tarif_repartition_quotients': normalized_values})


# ── Configuration : tranches d'age ───────────────────────────────────────────

@alsh_bp.route('/api/alsh/tranches-age', methods=['POST'])
@login_required
def api_alsh_ajouter_tranche():
    """Ajoute une tranche d'age."""
    if not _peut_acceder():
        return jsonify({'error': 'Accès non autorisé'}), 403

    libelle = (request.json or {}).get('libelle', '').strip()
    if not libelle:
        return jsonify({'error': 'Le libellé est requis.'}), 400

    conn = get_db()
    try:
        max_ordre = conn.execute(
            'SELECT COALESCE(MAX(ordre), 0) FROM alsh_tranches_age'
        ).fetchone()[0]
        cursor = conn.cursor()
        cursor.execute(
            'INSERT INTO alsh_tranches_age (libelle, ordre) VALUES (?, ?)',
            (libelle, max_ordre + 1)
        )
        conn.commit()
        return jsonify({'success': True, 'id': cursor.lastrowid, 'libelle': libelle})
    finally:
        conn.close()


@alsh_bp.route('/api/alsh/tranches-age/<int:tranche_id>', methods=['DELETE'])
@login_required
def api_alsh_supprimer_tranche(tranche_id):
    """Supprime une tranche d'age (si non utilisee)."""
    if not _peut_acceder():
        return jsonify({'error': 'Accès non autorisé'}), 403

    conn = get_db()
    try:
        # Verifier si utilisee dans les codes ou les donnees NOE
        nb_codes = conn.execute(
            'SELECT COUNT(*) FROM alsh_config_codes WHERE tranche_age_id = ?', (tranche_id,)
        ).fetchone()[0]
        nb_noe = conn.execute(
            'SELECT COUNT(*) FROM alsh_saisie_noe WHERE tranche_age_id = ?', (tranche_id,)
        ).fetchone()[0]
        if nb_codes + nb_noe > 0:
            return jsonify({
                'error': 'Cette tranche d\'âge est utilisée dans des données existantes.'
            }), 400

        conn.execute('DELETE FROM alsh_tranches_age WHERE id = ?', (tranche_id,))
        conn.commit()
        return jsonify({'success': True})
    finally:
        conn.close()


# ── Configuration : periodes ─────────────────────────────────────────────────

@alsh_bp.route('/api/alsh/periodes', methods=['POST'])
@login_required
def api_alsh_ajouter_periode():
    """Ajoute une ligne/periode."""
    if not _peut_acceder():
        return jsonify({'error': 'Accès non autorisé'}), 403

    data = request.json or {}
    nom = data.get('nom', '').strip()
    if not nom:
        return jsonify({'error': 'Le nom est requis.'}), 400

    conn = get_db()
    try:
        max_ordre = conn.execute(
            'SELECT COALESCE(MAX(ordre), 0) FROM alsh_periodes'
        ).fetchone()[0]
        cursor = conn.cursor()
        cursor.execute(
            'INSERT INTO alsh_periodes (nom, type, ordre) VALUES (?, ?, ?)',
            (nom, 'custom', max_ordre + 1)
        )
        conn.commit()
        return jsonify({'success': True, 'id': cursor.lastrowid, 'nom': nom})
    finally:
        conn.close()


@alsh_bp.route('/api/alsh/periodes/<int:periode_id>', methods=['DELETE'])
@login_required
def api_alsh_supprimer_periode(periode_id):
    """Supprime une periode personnalisee."""
    if not _peut_acceder():
        return jsonify({'error': 'Accès non autorisé'}), 403

    conn = get_db()
    try:
        periode = conn.execute(
            'SELECT type FROM alsh_periodes WHERE id = ?', (periode_id,)
        ).fetchone()
        if not periode:
            return jsonify({'error': 'Période introuvable.'}), 404

        nb_codes = conn.execute(
            'SELECT COUNT(*) FROM alsh_config_codes WHERE periode_id = ?', (periode_id,)
        ).fetchone()[0]
        nb_noe = conn.execute(
            'SELECT COUNT(*) FROM alsh_saisie_noe WHERE periode_id = ?', (periode_id,)
        ).fetchone()[0]
        if nb_codes + nb_noe > 0:
            return jsonify({
                'error': 'Cette période est utilisée dans des données existantes.'
            }), 400

        conn.execute('DELETE FROM alsh_periodes WHERE id = ?', (periode_id,))
        conn.commit()
        return jsonify({'success': True})
    finally:
        conn.close()


# ── Codes analytiques ────────────────────────────────────────────────────────

@alsh_bp.route('/api/alsh/codes')
@login_required
def api_alsh_get_codes():
    """Retourne les codes analytiques mappes pour une annee."""
    if not _peut_acceder():
        return jsonify({'error': 'Accès non autorisé'}), 403

    annee = request.args.get('annee', type=int)
    if not annee:
        return jsonify({'error': 'Année requise.'}), 400

    conn = get_db()
    try:
        rows = conn.execute('''
            SELECT periode_id, tranche_age_id, code1, code2, code3
            FROM alsh_config_codes
            WHERE annee = ?
        ''', (annee,)).fetchall()
        return jsonify({'codes': [dict(r) for r in rows]})
    finally:
        conn.close()


@alsh_bp.route('/api/alsh/codes', methods=['POST'])
@login_required
def api_alsh_save_codes():
    """Sauvegarde le mapping codes analytiques pour une cellule (annee, periode, tranche)."""
    if not _peut_acceder():
        return jsonify({'error': 'Accès non autorisé'}), 403

    data = request.json or {}
    annee = data.get('annee')
    periode_id = data.get('periode_id')
    tranche_age_id = data.get('tranche_age_id')
    code1 = (data.get('code1') or '').strip() or None
    code2 = (data.get('code2') or '').strip() or None
    code3 = (data.get('code3') or '').strip() or None

    if not all([annee, periode_id, tranche_age_id]):
        return jsonify({'error': 'Paramètres incomplets.'}), 400

    conn = get_db()
    try:
        conn.execute('''
            INSERT INTO alsh_config_codes (annee, periode_id, tranche_age_id, code1, code2, code3, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(annee, periode_id, tranche_age_id) DO UPDATE SET
                code1 = excluded.code1,
                code2 = excluded.code2,
                code3 = excluded.code3,
                updated_at = CURRENT_TIMESTAMP
        ''', (annee, periode_id, tranche_age_id, code1, code2, code3))
        conn.commit()
        return jsonify({'success': True})
    finally:
        conn.close()


# ── Saisie donnees NOE ────────────────────────────────────────────────────────

@alsh_bp.route('/api/alsh/noe')
@login_required
def api_alsh_get_noe():
    """Retourne les donnees NOE pour une annee."""
    if not _peut_acceder():
        return jsonify({'error': 'Accès non autorisé'}), 403

    annee = request.args.get('annee', type=int)
    if not annee:
        return jsonify({'error': 'Année requise.'}), 400

    conn = get_db()
    try:
        rows = conn.execute('''
            SELECT periode_id, tranche_age_id, heures_presence, nb_enfants
            FROM alsh_saisie_noe
            WHERE annee = ?
        ''', (annee,)).fetchall()
        return jsonify({'noe': [dict(r) for r in rows]})
    finally:
        conn.close()


@alsh_bp.route('/api/alsh/noe', methods=['POST'])
@login_required
def api_alsh_save_noe():
    """Sauvegarde une saisie NOE pour une cellule (annee, periode, tranche)."""
    if not _peut_acceder():
        return jsonify({'error': 'Accès non autorisé'}), 403

    data = request.json or {}
    annee = data.get('annee')
    periode_id = data.get('periode_id')
    tranche_age_id = data.get('tranche_age_id')

    try:
        heures = float(data.get('heures_presence') or 0)
        enfants = int(data.get('nb_enfants') or 0)
    except (ValueError, TypeError):
        return jsonify({'error': 'Valeurs numériques invalides.'}), 400

    if not all([annee, periode_id, tranche_age_id]):
        return jsonify({'error': 'Paramètres incomplets.'}), 400

    conn = get_db()
    try:
        conn.execute('''
            INSERT INTO alsh_saisie_noe
                (annee, periode_id, tranche_age_id, heures_presence, nb_enfants, updated_at)
            VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(annee, periode_id, tranche_age_id) DO UPDATE SET
                heures_presence = excluded.heures_presence,
                nb_enfants = excluded.nb_enfants,
                updated_at = CURRENT_TIMESTAMP
        ''', (annee, periode_id, tranche_age_id, heures, enfants))
        conn.commit()
        return jsonify({'success': True})
    finally:
        conn.close()


# ── Tableau de bord ──────────────────────────────────────────────────────────

def _build_tableau(conn, annee):
    """Construit les donnees du tableau de bord pour une annee.

    Charges : filtrees par les mois couverts par chaque periode de vacances
      (evite le double-comptage quand deux periodes partagent le meme code).

    Produits : les subventions s'appliquent a la globalite des vacances, pas
      mois par mois. Si plusieurs periodes de vacances partagent le meme code
      analytique (pour la meme tranche d'age), le total annuel des produits est
      reparti au prorata du nombre de jours de chaque vacation.
      Si les codes sont distincts, chaque periode recoit le total de son code.

    Mercredis / periodes custom : toujours le total annuel sans filtrage.
    """
    periodes = conn.execute(
        'SELECT id, nom, type, ordre FROM alsh_periodes WHERE active = 1 ORDER BY ordre, id'
    ).fetchall()
    tranches = conn.execute(
        'SELECT id, libelle, ordre FROM alsh_tranches_age WHERE active = 1 ORDER BY ordre, id'
    ).fetchall()

    # Charger les codes analytiques de l'annee
    codes_rows = conn.execute(
        'SELECT periode_id, tranche_age_id, code1, code2, code3 FROM alsh_config_codes WHERE annee = ?',
        (annee,)
    ).fetchall()
    codes_map = {(r['periode_id'], r['tranche_age_id']): [r['code1'], r['code2'], r['code3']]
                 for r in codes_rows}

    # Charger les donnees NOE de l'annee
    noe_rows = conn.execute(
        'SELECT periode_id, tranche_age_id, heures_presence, nb_enfants FROM alsh_saisie_noe WHERE annee = ?',
        (annee,)
    ).fetchall()
    noe_map = {(r['periode_id'], r['tranche_age_id']): (r['heures_presence'], r['nb_enfants'])
               for r in noe_rows}

    # Info par periode : (mois_filter, label, nb_jours)
    periode_info = _build_periode_info(conn, periodes, annee)

    taux_logistique_global = _get_taux_logistique_global(conn, annee)
    coeff_logistique = 1 + ((taux_logistique_global or 0.0) / 100.0)

    # Collecter tous les codes analytiques utilises pour cette annee
    tous_les_codes = set()
    for codes in codes_map.values():
        tous_les_codes.update(c for c in codes if c)

    # Agreger les charges par (code, mois) et les produits par code (total annee)
    charges_by_code_mois = {}  # {(code, mois): total}  – pour les charges filtrées
    charges_by_code = {}       # {code: total annee}    – pour les périodes sans filtre
    produits_by_code = {}      # {code: total annee}    – les produits ne sont pas filtrés
    subventions_by_code = {}   # {code: total annee}    – produits de subventions (hors 7064xx)

    if tous_les_codes:
        codes_list = list(tous_les_codes)
        placeholders = ','.join('?' * len(codes_list))
        params = [annee] + codes_list

        charges_rows = conn.execute(
            'SELECT code_analytique, mois, COALESCE(SUM(montant), 0) as total'
            ' FROM bilan_fec_donnees'
            " WHERE annee = ? AND compte_num LIKE '6%'"
            ' AND code_analytique IN (' + placeholders + ')'
            ' GROUP BY code_analytique, mois',
            params
        ).fetchall()
        for r in charges_rows:
            km = (r['code_analytique'], r['mois'])
            charges_by_code_mois[km] = r['total']
            c = r['code_analytique']
            charges_by_code[c] = charges_by_code.get(c, 0.0) + r['total']

        produits_subventions_params = [f'{_FAMILY_PAYMENTS_ACCOUNT_PREFIX}%', annee] + codes_list
        produits_rows = conn.execute(
            'SELECT code_analytique, '
            '       COALESCE(SUM(montant), 0) as total, '
            "       COALESCE(SUM(CASE WHEN compte_num LIKE '7%' AND compte_num NOT LIKE ? "
            '                         THEN montant ELSE 0 END), 0) as total_subventions '
            ' FROM bilan_fec_donnees'
            " WHERE annee = ? AND compte_num LIKE '7%'"
            ' AND code_analytique IN (' + placeholders + ')'
            ' GROUP BY code_analytique',
            produits_subventions_params
        ).fetchall()
        for r in produits_rows:
            produits_by_code[r['code_analytique']] = r['total']
            subventions_by_code[r['code_analytique']] = r['total_subventions']

    # ── Pro-rata des produits pour les vacances partageant un meme code ────────
    # Pour chaque (code, tranche_id), recenser les periodes de vacances qui
    # utilisent ce (code, tranche). Si elles sont plusieurs, distribuer le total
    # des produits de ce code proportionnellement au nombre de jours.
    #
    # produits_prorata[(code, tid, pid)] = montant attribue a cette periode
    code_tid_vacances = {}  # {(code, tid): [(pid, nb_jours_or_None), ...]}
    for p in periodes:
        _, _, nb_jours = periode_info.get(p['id'], (None, None, None))
        if p['type'] != 'vacances':
            continue
        for t in tranches:
            codes_cell = codes_map.get((p['id'], t['id']), [None, None, None])
            for c in codes_cell:
                if c:
                    key = (c, t['id'])
                    code_tid_vacances.setdefault(key, []).append((p['id'], nb_jours))

    produits_prorata = {}  # {(code, tid, pid): montant}
    subventions_prorata = {}  # {(code, tid, pid): montant}
    for (code, tid), vac_list in code_tid_vacances.items():
        total_p = produits_by_code.get(code, 0.0)
        total_subv = subventions_by_code.get(code, 0.0)
        if len(vac_list) == 1:
            # Code utilise par une seule periode : elle recoit tout
            pid, _ = vac_list[0]
            produits_prorata[(code, tid, pid)] = total_p
            subventions_prorata[(code, tid, pid)] = total_subv
        elif any(j is None for _, j in vac_list):
            # Au moins une duree inconnue → repartition egale entre toutes
            for pid, _ in vac_list:
                produits_prorata[(code, tid, pid)] = total_p / len(vac_list)
                subventions_prorata[(code, tid, pid)] = total_subv / len(vac_list)
        else:
            total_jours = sum(j for _, j in vac_list)
            for pid, nb_j in vac_list:
                if total_jours > 0:
                    produits_prorata[(code, tid, pid)] = total_p * nb_j / total_jours
                    subventions_prorata[(code, tid, pid)] = total_subv * nb_j / total_jours
                else:
                    produits_prorata[(code, tid, pid)] = total_p / len(vac_list)
                    subventions_prorata[(code, tid, pid)] = total_subv / len(vac_list)

    # ── Construction des lignes ────────────────────────────────────────────────
    lignes = []
    total_charges = 0.0
    total_produits = 0.0
    total_subventions = 0.0
    total_heures = 0.0
    total_enfants = 0

    for periode in periodes:
        mois_filter, date_label, _ = periode_info.get(periode['id'], (None, None, None))
        for tranche in tranches:
            key = (periode['id'], tranche['id'])
            codes = codes_map.get(key, [None, None, None])
            heures, enfants = noe_map.get(key, (0.0, 0))

            codes_valides = [c for c in codes if c]

            # Charges : filtrees par mois pour les vacances avec dates connues
            if mois_filter is not None:
                charges_brutes = sum(
                    charges_by_code_mois.get((c, m), 0.0)
                    for c in codes_valides
                    for m in mois_filter
                )
            else:
                charges_brutes = sum(charges_by_code.get(c, 0.0) for c in codes_valides)
            charges = round(round(charges_brutes, 6) * coeff_logistique, 2)

            # Produits : pro-rata pour les vacances, total annuel sinon
            if periode['type'] == 'vacances' and any(
                (c, tranche['id'], periode['id']) in produits_prorata for c in codes_valides
            ):
                produits = round(sum(
                    produits_prorata.get((c, tranche['id'], periode['id']), 0.0)
                    for c in codes_valides
                ), 2)
                subventions = round(sum(
                    subventions_prorata.get((c, tranche['id'], periode['id']), 0.0)
                    for c in codes_valides
                ), 2)
            else:
                produits = round(sum(produits_by_code.get(c, 0.0) for c in codes_valides), 2)
                subventions = round(sum(subventions_by_code.get(c, 0.0) for c in codes_valides), 2)

            resultat = produits - charges
            cout_heure = (charges / heures) if heures > 0 else None
            cout_enfant = (charges / enfants) if enfants > 0 else None
            a_charge_enfant = ((charges - subventions) / enfants) if enfants > 0 else None
            taux_couverture = ((produits / charges) * 100) if charges > 0 else None

            ligne = {
                'periode_id': periode['id'],
                'periode_nom': periode['nom'],
                'periode_type': periode['type'],
                'periode_date_label': date_label,
                'tranche_id': tranche['id'],
                'tranche_libelle': tranche['libelle'],
                'codes': codes_valides,
                'heures_presence': heures,
                'nb_enfants': enfants,
                'charges': charges,
                'produits': produits,
                'resultat': round(resultat, 2),
                'reste_a_charge': round(charges - subventions, 2),
                'cout_heure': round(cout_heure, 2) if cout_heure is not None else None,
                'cout_enfant': round(cout_enfant, 2) if cout_enfant is not None else None,
                'a_charge_enfant': round(a_charge_enfant, 2) if a_charge_enfant is not None else None,
                'taux_couverture': round(taux_couverture, 1) if taux_couverture is not None else None,
                # Données pour le détail des charges (identifiants pour la requête)
                'charges_mois_filter': sorted(mois_filter) if mois_filter is not None else None,
            }
            lignes.append(ligne)
            total_charges += charges
            total_produits += produits
            total_subventions += subventions
            total_heures += heures
            total_enfants += enfants

    total_resultat = total_produits - total_charges
    total_reste_a_charge = total_charges - total_subventions
    total_a_charge_enfant = (total_reste_a_charge / total_enfants) if total_enfants > 0 else None
    total_taux = ((total_produits / total_charges) * 100) if total_charges > 0 else None

    return {
        'annee': annee,
        'taux_logistique_global': taux_logistique_global,
        'taux_logistique_manquant': (
            taux_logistique_global is None or taux_logistique_global == 0
        ),
        'periodes': [dict(p) for p in periodes],
        'tranches': [dict(t) for t in tranches],
        'lignes': lignes,
        'totaux': {
            'heures_presence': round(total_heures, 2),
            'nb_enfants': total_enfants,
            'charges': round(total_charges, 2),
            'produits': round(total_produits, 2),
            'resultat': round(total_resultat, 2),
            'reste_a_charge': round(total_reste_a_charge, 2),
            'a_charge_enfant': round(total_a_charge_enfant, 2) if total_a_charge_enfant is not None else None,
            'taux_couverture': round(total_taux, 1) if total_taux is not None else None,
        },
    }



@alsh_bp.route('/api/alsh/tableau')
@login_required
def api_alsh_tableau():
    """Retourne les donnees du tableau de bord pour une annee."""
    if not _peut_acceder():
        return jsonify({'error': 'Accès non autorisé'}), 403

    annee = request.args.get('annee', type=int)
    if not annee:
        return jsonify({'error': 'Année requise.'}), 400

    conn = get_db()
    try:
        data = _build_tableau(conn, annee)
        return jsonify(data)
    finally:
        conn.close()


@alsh_bp.route('/api/alsh/comparaison')
@login_required
def api_alsh_comparaison():
    """Retourne les donnees comparatives N / N-1 / N-2."""
    if not _peut_acceder():
        return jsonify({'error': 'Accès non autorisé'}), 403

    annee = request.args.get('annee', type=int)
    if not annee:
        return jsonify({'error': 'Année requise.'}), 400

    conn = get_db()
    try:
        # Annees ayant des donnees FEC ou NOE
        annees_fec = {r['annee'] for r in conn.execute(
            'SELECT DISTINCT annee FROM bilan_fec_imports'
        ).fetchall()}
        annees_noe = {r['annee'] for r in conn.execute(
            'SELECT DISTINCT annee FROM alsh_saisie_noe'
        ).fetchall()}
        annees_dispo = sorted(annees_fec | annees_noe, reverse=True)

        resultats = {}
        for a in [annee, annee - 1, annee - 2]:
            if a in annees_dispo or a == annee:
                resultats[str(a)] = _build_tableau(conn, a)

        return jsonify({
            'annees_dispo': annees_dispo,
            'comparaison': resultats,
        })
    finally:
        conn.close()


# ── Codes analytiques disponibles (pour autocomplete) ────────────────────────

@alsh_bp.route('/api/alsh/codes-disponibles')
@login_required
def api_alsh_codes_disponibles():
    """Retourne la liste des codes analytiques disponibles dans les donnees FEC."""
    if not _peut_acceder():
        return jsonify({'error': 'Accès non autorisé'}), 403

    annee = request.args.get('annee', type=int)
    conn = get_db()
    try:
        if annee:
            rows = conn.execute('''
                SELECT DISTINCT code_analytique
                FROM bilan_fec_donnees
                WHERE annee = ? AND code_analytique IS NOT NULL AND code_analytique != ''
                ORDER BY code_analytique
            ''', (annee,)).fetchall()
        else:
            rows = conn.execute('''
                SELECT DISTINCT code_analytique
                FROM bilan_fec_donnees
                WHERE code_analytique IS NOT NULL AND code_analytique != ''
                ORDER BY code_analytique
            ''').fetchall()
        return jsonify({'codes': [r['code_analytique'] for r in rows]})
    finally:
        conn.close()


# ── Détail des charges (pour la modale) ──────────────────────────────────────

@alsh_bp.route('/api/alsh/charges-detail')
@login_required
def api_alsh_charges_detail():
    """Retourne les lignes FEC individuelles de charges pour affichage en détail.

    Paramètres GET :
      - annee  : int (obligatoire)
      - codes  : codes analytiques séparés par des virgules (obligatoire)
      - mois   : mois séparés par des virgules (optionnel, filtrage pour vacances)

    Retourne les lignes agrégées par (compte_num, libelle, code_analytique, mois)
    ordonnées par mois puis compte, avec le montant total et le nb de lignes.
    """
    if not _peut_acceder():
        return jsonify({'error': 'Accès non autorisé'}), 403

    annee = request.args.get('annee', type=int)
    codes_param = request.args.get('codes', '').strip()
    mois_param = request.args.get('mois', '').strip()

    if not annee or not codes_param:
        return jsonify({'error': 'Paramètres annee et codes requis.'}), 400

    codes = [c.strip() for c in codes_param.split(',') if c.strip()]
    if not codes:
        return jsonify({'error': 'Au moins un code analytique est requis.'}), 400

    mois_filter = []
    if mois_param:
        for m in mois_param.split(','):
            try:
                mois_filter.append(int(m.strip()))
            except ValueError:
                pass

    conn = get_db()
    try:
        ph = ','.join('?' * len(codes))
        params_base = [annee] + codes

        if mois_filter:
            ph_mois = ','.join('?' * len(mois_filter))
            rows = conn.execute(
                'SELECT compte_num, libelle, code_analytique, mois,'
                ' COALESCE(SUM(montant), 0) AS montant_total, COUNT(*) AS nb_lignes'
                ' FROM bilan_fec_donnees'
                " WHERE annee = ? AND compte_num LIKE '6%'"
                ' AND code_analytique IN (' + ph + ')'
                ' AND mois IN (' + ph_mois + ')'
                ' GROUP BY compte_num, libelle, code_analytique, mois'
                ' ORDER BY mois, compte_num',
                params_base + mois_filter
            ).fetchall()
        else:
            rows = conn.execute(
                'SELECT compte_num, libelle, code_analytique, mois,'
                ' COALESCE(SUM(montant), 0) AS montant_total, COUNT(*) AS nb_lignes'
                ' FROM bilan_fec_donnees'
                " WHERE annee = ? AND compte_num LIKE '6%'"
                ' AND code_analytique IN (' + ph + ')'
                ' GROUP BY compte_num, libelle, code_analytique, mois'
                ' ORDER BY mois, compte_num',
                params_base
            ).fetchall()

        return jsonify({'lignes': [dict(r) for r in rows]})
    finally:
        conn.close()
