# Politique de sécurité

## Versions prises en charge

Versions actuellement prises en charge par les mises à jour de sécurité.

| Version | Prise en charge |
| ------- | ----------------|
| 1.1.x | :white_check_mark: |
| Autres versions | :x: |

## Signaler une vulnérabilité

Signalez tout problème de sécurité ici : https://github.com/Cyril-CB/CS-PILOT/issues avec le bouton "New issue".
